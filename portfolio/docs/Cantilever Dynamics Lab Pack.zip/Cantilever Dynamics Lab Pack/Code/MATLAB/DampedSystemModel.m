%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                                          %%
%%           Damped System Model            %%
%%                  for                     %%
%%      Cantilever Beam Dynamics Lab        %%
%%              submitted by                %%
%%      P. Berdos, A. Shah, P. Soucy        %%
%%                                          %%
%%        MATLAB Version: R2016b            %%
%%         Code Revision: Final Build       %%
%%         Revision Date: 2016 12 08        %%
%%                                          %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%

clear
clc

%%----- Parameters -----%
E = 6.89e10;        %N/m^2  % Elastic Modulus
p = 2700;           %kg/m^3 % Density
g = 9.81;           %m/s^2  % Gravitational Constant
b = 0.0292354;      %m      % Beam Width
h = 0.0016764;      %m      % Beam Thickness
L = 0.422275;       %m      % Beam Length
m_mass = 0.0045;    %kg     % Mass of oscillating mass
m_motor = 0.0335;   %kg     % Mass of motor
m_wires = 0.001;    %kg     % Mass of wires

%----- Equivalent Beam Stiffness -----%
I = (1/12)*b*h^3;   % Section Modulus of rectangular beam 
k = 3*E*I/L^3       % Effective stiffness

%----- Equivalent Beam Mass -----%
V = b*h*L;                  % Beam Volume
m_beam = p*V;               % Beam Mass
m_dist = m_beam+m_wires;    % Distributed Mass
m_tip = m_motor+m_mass;     % Tip Mass
m = (33/140)*m_dist+m_tip   % Effective Tip Mass

%----- Equivalent Beam Damping -----%
zeta = 0.006405;        % Input from experimentation
c = zeta*2*sqrt(m*k)	% Effective damping

%----- System Transfer Function -----%
TF = tf([0 0 1],[m c k]);   % Define TF for Impulse Input

w_d = sqrt(k/m)*sqrt(1-zeta^2)/(2*pi);    % Natural frequency
w_beat = 4.06;         % Beating frequency

% Select an input frequency
w = w_d;
F = m_mass*0.0381*(w*2*pi)^2;   % Eccentric mass force

subplot(1,2,1);     % 2 Plot, Position 1
bode(TF)            % Plot Bode Frequency Output
subplot(1,2,2);     % 2 Plot, Position 2
rlocus(TF)          % Plot Root Locus

% Be sure to convert to time frequency